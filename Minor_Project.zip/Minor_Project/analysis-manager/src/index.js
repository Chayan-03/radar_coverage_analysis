const express = require('express');
const cors = require('cors');
const { Kafka } = require('kafkajs');
const { Pool } = require('pg');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'radar_coverage',
  user: process.env.DB_USER || 'radar_user',
  password: process.env.DB_PASSWORD || 'radar_pass',
});

// Kafka setup
const kafkaBroker = process.env.KAFKA_BROKER || 'kafka:9092';
console.log(`[${new Date().toISOString()}] Kafka broker configured as: ${kafkaBroker}`);
const kafka = new Kafka({
  clientId: 'analysis-manager',
  brokers: [kafkaBroker],
});

const producer = kafka.producer();
const consumer = kafka.consumer({ groupId: 'analysis-manager-group' });

// Job status tracking (in-memory, could be moved to Redis in production)
const jobStatus = new Map();

// Initialize Kafka
async function initKafka() {
  try {
    await producer.connect();
    console.log('Kafka producer connected');
    
    await consumer.connect();
    console.log('Kafka consumer connected');
    
    await consumer.subscribe({ topic: 'computation-results', fromBeginning: false });
    
    await consumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        try {
          const result = JSON.parse(message.value.toString());
          console.log(`[${new Date().toISOString()}] Received computation result for job ${result.jobId}`);
          
          // Update job status
          if (jobStatus.has(result.jobId)) {
            const currentStatus = jobStatus.get(result.jobId);
            jobStatus.set(result.jobId, {
              ...currentStatus,
              status: result.status || 'completed',
              result: result,
              completedAt: new Date(),
            });
            console.log(`[${new Date().toISOString()}] Updated job ${result.jobId} status to ${result.status || 'completed'}`);
          } else {
            console.warn(`[${new Date().toISOString()}] Received result for unknown job ${result.jobId}`);
          }
          
          // Handle failed jobs
          if (result.status === 'failed') {
            console.error(`[${new Date().toISOString()}] Job ${result.jobId} failed: ${result.error || 'Unknown error'}`);
          }
        } catch (error) {
          console.error(`[${new Date().toISOString()}] Error processing computation result:`, error);
          console.error('Message content:', message.value?.toString());
        }
      },
    });
    
    console.log('Kafka initialized successfully');
  } catch (error) {
    console.error('Failed to initialize Kafka:', error);
    throw error;
  }
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', service: 'analysis-manager' });
});

// Create new radar analysis
app.post('/api/analysis', async (req, res) => {
  try {
    const {
      name,
      latitude,
      longitude,
      frequency_mhz,
      transmit_power_dbm,
      antenna_height_m,
      antenna_gain_dbi,
      minimum_signal_threshold_dbm = -100,
    } = req.body;

    // Validate input
    if (!name || !latitude || !longitude || !frequency_mhz || 
        !transmit_power_dbm || !antenna_height_m || !antenna_gain_dbi) {
      console.warn(`[${new Date().toISOString()}] Invalid request: missing required fields`);
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['name', 'latitude', 'longitude', 'frequency_mhz', 
                   'transmit_power_dbm', 'antenna_height_m', 'antenna_gain_dbi']
      });
    }

    // Validate numeric ranges
    if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      return res.status(400).json({ 
        error: 'Invalid coordinates',
        message: 'Latitude must be between -90 and 90, Longitude between -180 and 180'
      });
    }

    if (frequency_mhz <= 0 || antenna_height_m < 0) {
      return res.status(400).json({ 
        error: 'Invalid parameter values',
        message: 'Frequency must be positive, antenna height must be non-negative'
      });
    }

    console.log(`[${new Date().toISOString()}] Creating new analysis: ${name}`);

    // Create scenario in database
    let scenarioResult;
    try {
      scenarioResult = await pool.query(
        `INSERT INTO radar_scenarios 
         (name, latitude, longitude, frequency_mhz, transmit_power_dbm, 
          antenna_height_m, antenna_gain_dbi, minimum_signal_threshold_dbm)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING id`,
        [name, latitude, longitude, frequency_mhz, transmit_power_dbm,
         antenna_height_m, antenna_gain_dbi, minimum_signal_threshold_dbm]
      );
    } catch (dbError) {
      console.error(`[${new Date().toISOString()}] Database error:`, dbError);
      return res.status(500).json({ 
        error: 'Database error', 
        message: 'Failed to create scenario in database' 
      });
    }

    const scenarioId = scenarioResult.rows[0].id;
    const jobId = uuidv4();

    // Track job status
    jobStatus.set(jobId, {
      jobId,
      scenarioId,
      status: 'pending',
      createdAt: new Date(),
    });

    // Publish to Kafka
    try {
      await producer.send({
        topic: 'analysis-requests',
        messages: [{
          key: jobId,
          value: JSON.stringify({
            jobId,
            scenarioId,
            latitude,
            longitude,
            frequency_mhz,
            transmit_power_dbm,
            antenna_height_m,
            antenna_gain_dbi,
            minimum_signal_threshold_dbm,
          }),
        }],
      });
      console.log(`[${new Date().toISOString()}] Published analysis request to Kafka: ${jobId}`);
    } catch (kafkaError) {
      console.error(`[${new Date().toISOString()}] Kafka error:`, kafkaError);
      // Update job status to failed
      jobStatus.set(jobId, {
        ...jobStatus.get(jobId),
        status: 'failed',
        error: 'Failed to publish to Kafka',
      });
      return res.status(500).json({ 
        error: 'Message queue error', 
        message: 'Failed to submit analysis request' 
      });
    }

    res.status(202).json({
      jobId,
      scenarioId,
      status: 'pending',
      message: 'Analysis request submitted',
    });
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Unexpected error creating analysis:`, error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Get job status
app.get('/api/analysis/:jobId/status', (req, res) => {
  const { jobId } = req.params;
  const status = jobStatus.get(jobId);
  
  if (!status) {
    return res.status(404).json({ error: 'Job not found' });
  }
  
  res.json(status);
});

// Get all scenarios
app.get('/api/scenarios', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM radar_scenarios ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching scenarios:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Get scenario with coverage result
app.get('/api/scenarios/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const scenarioResult = await pool.query(
      'SELECT * FROM radar_scenarios WHERE id = $1',
      [id]
    );
    
    if (scenarioResult.rows.length === 0) {
      return res.status(404).json({ error: 'Scenario not found' });
    }
    
    const coverageResult = await pool.query(
      `SELECT id, coverage_polygon, coverage_radius_km, computed_at 
       FROM coverage_results 
       WHERE scenario_id = $1 
       ORDER BY computed_at DESC 
       LIMIT 1`,
      [id]
    );
    
    const scenario = scenarioResult.rows[0];
    if (coverageResult.rows.length > 0) {
      const coverage = coverageResult.rows[0];
      // Convert PostGIS geometry to GeoJSON
      const geoJsonResult = await pool.query(
        'SELECT ST_AsGeoJSON($1::geometry) as geojson',
        [coverage.coverage_polygon]
      );
      scenario.coverage = {
        ...coverage,
        geojson: JSON.parse(geoJsonResult.rows[0].geojson),
      };
    }
    
    res.json(scenario);
  } catch (error) {
    console.error('Error fetching scenario:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Get all coverage results
app.get('/api/coverage', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT cr.id, cr.scenario_id, cr.coverage_radius_km, cr.computed_at,
              ST_AsGeoJSON(cr.coverage_polygon) as geojson,
              rs.name, rs.latitude, rs.longitude
       FROM coverage_results cr
       JOIN radar_scenarios rs ON cr.scenario_id = rs.id
       ORDER BY cr.computed_at DESC`
    );
    
    const coverageData = result.rows.map(row => ({
      id: row.id,
      scenario_id: row.scenario_id,
      scenario_name: row.name,
      latitude: row.latitude,
      longitude: row.longitude,
      coverage_radius_km: row.coverage_radius_km,
      computed_at: row.computed_at,
      geojson: JSON.parse(row.geojson),
    }));
    
    res.json(coverageData);
  } catch (error) {
    console.error('Error fetching coverage:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(`[${new Date().toISOString()}] Unhandled error:`, err);
  res.status(500).json({ 
    error: 'Internal server error', 
    message: err.message 
  });
});

// Start server
async function startServer() {
  try {
    // Test database connection
    console.log(`[${new Date().toISOString()}] Testing database connection...`);
    await pool.query('SELECT NOW()');
    console.log(`[${new Date().toISOString()}] Database connected successfully`);
    
    // Initialize Kafka
    await initKafka();
    
    app.listen(PORT, () => {
      console.log(`[${new Date().toISOString()}] Analysis Manager Service running on port ${PORT}`);
    });
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Failed to start server:`, error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await producer.disconnect();
  await consumer.disconnect();
  await pool.end();
  process.exit(0);
});

startServer();

