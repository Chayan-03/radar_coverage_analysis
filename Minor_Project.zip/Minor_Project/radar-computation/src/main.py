import os
import json
import math
import logging
from kafka import KafkaConsumer, KafkaProducer
from kafka.errors import KafkaError
import psycopg2
from psycopg2.extras import RealDictCursor
from shapely.geometry import Point, Polygon
from shapely.ops import transform
import pyproj
from functools import partial
from dotenv import load_dotenv

load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Database configuration
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': os.getenv('DB_PORT', '5432'),
    'database': os.getenv('DB_NAME', 'radar_coverage'),
    'user': os.getenv('DB_USER', 'radar_user'),
    'password': os.getenv('DB_PASSWORD', 'radar_pass'),
}

# Kafka configuration
KAFKA_BROKER = os.getenv('KAFKA_BROKER', 'kafka:9092')
REQUEST_TOPIC = 'analysis-requests'
RESULT_TOPIC = 'computation-results'
logger.info(f"Kafka broker configured as: {KAFKA_BROKER}")


def calculate_free_space_path_loss(distance_km, frequency_mhz):
    """
    Calculate free-space path loss in dB
    Formula: L = 20*log10(d) + 20*log10(f) + 32.44
    where d is distance in km, f is frequency in MHz
    """
    if distance_km <= 0 or frequency_mhz <= 0:
        return float('inf')
    return 20 * math.log10(distance_km) + 20 * math.log10(frequency_mhz) + 32.44


def calculate_received_power(transmit_power_dbm, antenna_gain_dbi, path_loss_db):
    """
    Calculate received power in dBm
    received_power = transmit_power + antenna_gain - path_loss
    """
    return transmit_power_dbm + antenna_gain_dbi - path_loss_db


def calculate_coverage_radius(
    transmit_power_dbm,
    antenna_gain_dbi,
    frequency_mhz,
    minimum_signal_threshold_dbm
):
    """
    Calculate the maximum coverage radius where received power >= minimum threshold
    """
    # Binary search for the maximum distance
    min_distance = 0.1  # 100 meters
    max_distance = 1000.0  # 1000 km (reasonable upper bound)
    tolerance = 0.01  # 10 meters
    
    for _ in range(100):  # Max iterations
        mid_distance = (min_distance + max_distance) / 2
        path_loss = calculate_free_space_path_loss(mid_distance, frequency_mhz)
        received_power = calculate_received_power(
            transmit_power_dbm, antenna_gain_dbi, path_loss
        )
        
        if abs(received_power - minimum_signal_threshold_dbm) < 0.1:
            break
        
        if received_power > minimum_signal_threshold_dbm:
            min_distance = mid_distance
        else:
            max_distance = mid_distance
        
        if max_distance - min_distance < tolerance:
            break
    
    return mid_distance


def create_circular_polygon(center_lat, center_lon, radius_km, num_points=64):
    """
    Create a circular polygon around a center point
    Returns a Shapely Polygon in WGS84 (EPSG:4326)
    """
    # Create a local azimuthal equidistant projection centered on the point
    local_azimuthal_projection = f"+proj=aeqd +R=6371000 +units=m +lat_0={center_lat} +lon_0={center_lon}"
    
    # Transform to local projection
    wgs84_to_aeqd = pyproj.Transformer.from_proj(
        pyproj.Proj('+proj=longlat +datum=WGS84'),
        pyproj.Proj(local_azimuthal_projection)
    )
    
    aeqd_to_wgs84 = pyproj.Transformer.from_proj(
        pyproj.Proj(local_azimuthal_projection),
        pyproj.Proj('+proj=longlat +datum=WGS84')
    )
    
    # Create circle in local projection
    center_point = Point(center_lon, center_lat)
    center_projected = transform(wgs84_to_aeqd.transform, center_point)
    
    # Generate points on circle
    radius_m = radius_km * 1000
    points = []
    for i in range(num_points):
        angle = 2 * math.pi * i / num_points
        x = center_projected.x + radius_m * math.cos(angle)
        y = center_projected.y + radius_m * math.sin(angle)
        points.append((x, y))
    
    # Create polygon in local projection
    circle_projected = Polygon(points)
    
    # Transform back to WGS84
    circle_wgs84 = transform(aeqd_to_wgs84.transform, circle_projected)
    
    return circle_wgs84


def compute_radar_coverage(params):
    """
    Compute radar coverage polygon based on parameters
    """
    logger.info(f"Computing coverage for scenario {params.get('scenarioId')}")
    
    latitude = params['latitude']
    longitude = params['longitude']
    frequency_mhz = params['frequency_mhz']
    transmit_power_dbm = params['transmit_power_dbm']
    antenna_gain_dbi = params['antenna_gain_dbi']
    minimum_signal_threshold_dbm = params.get('minimum_signal_threshold_dbm', -100)
    
    # Calculate coverage radius
    coverage_radius_km = calculate_coverage_radius(
        transmit_power_dbm,
        antenna_gain_dbi,
        frequency_mhz,
        minimum_signal_threshold_dbm
    )
    
    logger.info(f"Coverage radius: {coverage_radius_km:.2f} km")
    
    # Create circular coverage polygon
    coverage_polygon = create_circular_polygon(
        latitude, longitude, coverage_radius_km
    )
    
    return {
        'coverage_radius_km': coverage_radius_km,
        'coverage_polygon': coverage_polygon,
    }


def save_coverage_result(scenario_id, coverage_radius_km, coverage_polygon):
    """
    Save coverage result to PostgreSQL/PostGIS database
    """
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        # Convert Shapely polygon to PostGIS WKT
        polygon_wkt = coverage_polygon.wkt
        
        # Insert into database
        cursor.execute(
            """
            INSERT INTO coverage_results (scenario_id, coverage_polygon, coverage_radius_km)
            VALUES (%s, ST_GeomFromText(%s, 4326), %s)
            RETURNING id
            """,
            (scenario_id, polygon_wkt, coverage_radius_km)
        )
        
        result_id = cursor.fetchone()[0]
        conn.commit()
        
        logger.info(f"Saved coverage result {result_id} for scenario {scenario_id}")
        
        cursor.close()
        conn.close()
        
        return result_id
    except Exception as e:
        logger.error(f"Error saving coverage result: {e}")
        raise


def process_analysis_request(message):
    """
    Process a single analysis request message
    """
    params = {}
    try:
        # Parse message
        params = json.loads(message.value.decode('utf-8'))
        job_id = params.get('jobId', 'unknown')
        logger.info(f"Processing request: {job_id}")
        
        # Validate required parameters
        required_params = ['scenarioId', 'latitude', 'longitude', 'frequency_mhz', 
                          'transmit_power_dbm', 'antenna_height_m', 'antenna_gain_dbi']
        missing = [p for p in required_params if p not in params]
        if missing:
            raise ValueError(f"Missing required parameters: {', '.join(missing)}")
        
        # Validate parameter ranges
        if not (-90 <= params['latitude'] <= 90):
            raise ValueError(f"Invalid latitude: {params['latitude']}")
        if not (-180 <= params['longitude'] <= 180):
            raise ValueError(f"Invalid longitude: {params['longitude']}")
        if params['frequency_mhz'] <= 0:
            raise ValueError(f"Frequency must be positive: {params['frequency_mhz']}")
        if params['antenna_height_m'] < 0:
            raise ValueError(f"Antenna height must be non-negative: {params['antenna_height_m']}")
        
        # Compute coverage
        result = compute_radar_coverage(params)
        
        # Save to database
        result_id = save_coverage_result(
            params['scenarioId'],
            result['coverage_radius_km'],
            result['coverage_polygon']
        )
        
        # Prepare result message
        result_message = {
            'jobId': params['jobId'],
            'scenarioId': params['scenarioId'],
            'resultId': result_id,
            'coverage_radius_km': result['coverage_radius_km'],
            'status': 'completed',
        }
        
        logger.info(f"Successfully processed request {job_id}, coverage radius: {result['coverage_radius_km']:.2f} km")
        return result_message
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {e}")
        return {
            'jobId': params.get('jobId', 'unknown'),
            'scenarioId': params.get('scenarioId'),
            'status': 'failed',
            'error': f'Invalid JSON format: {str(e)}',
        }
    except ValueError as e:
        logger.error(f"Validation error: {e}")
        return {
            'jobId': params.get('jobId', 'unknown'),
            'scenarioId': params.get('scenarioId'),
            'status': 'failed',
            'error': f'Validation error: {str(e)}',
        }
    except Exception as e:
        logger.error(f"Error processing request: {e}", exc_info=True)
        return {
            'jobId': params.get('jobId', 'unknown'),
            'scenarioId': params.get('scenarioId'),
            'status': 'failed',
            'error': str(e),
        }


def start_kafka_consumer():
    """
    Start Kafka consumer to process analysis requests
    """
    logger.info(f"Connecting to Kafka broker: {KAFKA_BROKER}")
    
    consumer = KafkaConsumer(
        REQUEST_TOPIC,
        bootstrap_servers=KAFKA_BROKER,
        value_deserializer=lambda m: m,
        auto_offset_reset='latest',
        enable_auto_commit=True,
        group_id='radar-computation-group',
    )
    
    producer = KafkaProducer(
        bootstrap_servers=KAFKA_BROKER,
        value_serializer=lambda v: json.dumps(v).encode('utf-8'),
    )
    
    logger.info("Kafka consumer started, waiting for messages...")
    
    try:
        for message in consumer:
            try:
                # Process the request
                result = process_analysis_request(message)
                
                # Send result back to Kafka
                try:
                    producer.send(RESULT_TOPIC, key=result['jobId'].encode('utf-8'), value=result)
                    producer.flush()
                    logger.info(f"Sent result to Kafka for job {result['jobId']}, status: {result['status']}")
                except Exception as kafka_error:
                    logger.error(f"Failed to send result to Kafka: {kafka_error}")
                    # Retry once
                    try:
                        producer.send(RESULT_TOPIC, key=result['jobId'].encode('utf-8'), value=result)
                        producer.flush()
                        logger.info(f"Retry successful for job {result['jobId']}")
                    except Exception as retry_error:
                        logger.error(f"Retry also failed for job {result['jobId']}: {retry_error}")
                
            except Exception as e:
                logger.error(f"Unexpected error processing message: {e}", exc_info=True)
                # Send error result
                try:
                    params = json.loads(message.value.decode('utf-8'))
                    error_result = {
                        'jobId': params.get('jobId', 'unknown'),
                        'scenarioId': params.get('scenarioId'),
                        'status': 'failed',
                        'error': f'Unexpected error: {str(e)}',
                    }
                    producer.send(RESULT_TOPIC, key=error_result['jobId'].encode('utf-8'), value=error_result)
                    producer.flush()
                    logger.info(f"Sent error result to Kafka for job {error_result['jobId']}")
                except Exception as send_error:
                    logger.error(f"Failed to send error result to Kafka: {send_error}")
                    
    except KeyboardInterrupt:
        logger.info("Shutting down consumer...")
    finally:
        consumer.close()
        producer.close()


if __name__ == '__main__':
    # Test database connection
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        conn.close()
        logger.info("Database connection successful")
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        exit(1)
    
    # Start Kafka consumer
    start_kafka_consumer()

