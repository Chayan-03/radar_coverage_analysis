-- Enable PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;

-- Create scenarios table
CREATE TABLE IF NOT EXISTS radar_scenarios (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    frequency_mhz DOUBLE PRECISION NOT NULL,
    transmit_power_dbm DOUBLE PRECISION NOT NULL,
    antenna_height_m DOUBLE PRECISION NOT NULL,
    antenna_gain_dbi DOUBLE PRECISION NOT NULL,
    minimum_signal_threshold_dbm DOUBLE PRECISION DEFAULT -100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create coverage results table
CREATE TABLE IF NOT EXISTS coverage_results (
    id SERIAL PRIMARY KEY,
    scenario_id INTEGER REFERENCES radar_scenarios(id) ON DELETE CASCADE,
    coverage_polygon GEOMETRY(POLYGON, 4326) NOT NULL,
    coverage_radius_km DOUBLE PRECISION NOT NULL,
    computed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_coverage_results_scenario ON coverage_results(scenario_id);
CREATE INDEX IF NOT EXISTS idx_coverage_results_geometry ON coverage_results USING GIST(coverage_polygon);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_radar_scenarios_updated_at BEFORE UPDATE ON radar_scenarios
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

