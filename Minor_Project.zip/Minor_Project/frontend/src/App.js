import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Polygon, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import axios from 'axios';
import './App.css';

// Fix for default marker icon in React-Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

// Use relative URL for API calls (nginx will proxy /api to analysis-manager)
const API_URL = process.env.REACT_APP_API_URL || '/api';

function LocationMarker({ position, setPosition }) {
  useMapEvents({
    click(e) {
      setPosition([e.latlng.lat, e.latlng.lng]);
    },
  });

  return position === null ? null : (
    <Marker position={position}>
      <Popup>Radar Location</Popup>
    </Marker>
  );
}

function App() {
  const [scenarios, setScenarios] = useState([]);
  const [coverageData, setCoverageData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [position, setPosition] = useState([28.6139, 77.2090]); // Default: New Delhi
  const [formData, setFormData] = useState({
    name: '',
    latitude: 28.6139,
    longitude: 77.2090,
    frequency_mhz: 2400,
    transmit_power_dbm: 30,
    antenna_height_m: 50,
    antenna_gain_dbi: 10,
    minimum_signal_threshold_dbm: -100,
  });
  const [activeJobId, setActiveJobId] = useState(null);
  const [jobStatus, setJobStatus] = useState(null);

  useEffect(() => {
    fetchScenarios();
    fetchCoverage();
    
    // Poll for job status if there's an active job
    let interval = null;
    if (activeJobId) {
      interval = setInterval(() => {
        checkJobStatus(activeJobId);
      }, 2000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [activeJobId]);

  const fetchScenarios = async () => {
    try {
      const response = await axios.get(`${API_URL}/scenarios`);
      setScenarios(response.data);
    } catch (err) {
      console.error('Error fetching scenarios:', err);
    }
  };

  const fetchCoverage = async () => {
    try {
      const response = await axios.get(`${API_URL}/coverage`);
      setCoverageData(response.data);
    } catch (err) {
      console.error('Error fetching coverage:', err);
    }
  };

  const checkJobStatus = async (jobId) => {
    try {
      const response = await axios.get(`${API_URL}/analysis/${jobId}/status`);
      setJobStatus(response.data);
      
      if (response.data.status === 'completed') {
        setActiveJobId(null);
        fetchScenarios();
        fetchCoverage();
        setLoading(false);
        setError(null);
      } else if (response.data.status === 'failed') {
        setActiveJobId(null);
        setLoading(false);
        setError('Analysis failed. Please check your parameters.');
      }
    } catch (err) {
      console.error('Error checking job status:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.post(`${API_URL}/analysis`, {
        ...formData,
        latitude: position[0],
        longitude: position[1],
      });
      
      setActiveJobId(response.data.jobId);
      setJobStatus(response.data);
    } catch (err) {
      setLoading(false);
      setError(err.response?.data?.error || 'Failed to submit analysis');
      console.error('Error submitting analysis:', err);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: parseFloat(value) || value,
    }));
  };

  const handleMapClick = (position) => {
    const [lat, lng] = position;
    setPosition(position);
    setFormData(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng,
    }));
  };

  // Convert GeoJSON to Leaflet coordinates
  const geoJsonToLeaflet = (geoJson) => {
    if (geoJson.type === 'Polygon' && geoJson.coordinates) {
      return geoJson.coordinates[0].map(coord => [coord[1], coord[0]]);
    }
    return [];
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Radar Coverage Analysis System</h1>
      </header>
      
      <div className="container">
        <div className="sidebar">
          <div className="form-section">
            <h2>Radar Parameters</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Scenario Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  placeholder="Enter scenario name"
                />
              </div>
              
              <div className="form-group">
                <label>Latitude</label>
                <input
                  type="number"
                  name="latitude"
                  value={formData.latitude}
                  onChange={handleInputChange}
                  step="0.0001"
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Longitude</label>
                <input
                  type="number"
                  name="longitude"
                  value={formData.longitude}
                  onChange={handleInputChange}
                  step="0.0001"
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Frequency (MHz)</label>
                <input
                  type="number"
                  name="frequency_mhz"
                  value={formData.frequency_mhz}
                  onChange={handleInputChange}
                  min="1"
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Transmit Power (dBm)</label>
                <input
                  type="number"
                  name="transmit_power_dbm"
                  value={formData.transmit_power_dbm}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Antenna Height (meters)</label>
                <input
                  type="number"
                  name="antenna_height_m"
                  value={formData.antenna_height_m}
                  onChange={handleInputChange}
                  min="0"
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Antenna Gain (dBi)</label>
                <input
                  type="number"
                  name="antenna_gain_dbi"
                  value={formData.antenna_gain_dbi}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Minimum Signal Threshold (dBm)</label>
                <input
                  type="number"
                  name="minimum_signal_threshold_dbm"
                  value={formData.minimum_signal_threshold_dbm}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <button type="submit" disabled={loading} className="submit-btn">
                {loading ? 'Processing...' : 'Calculate Coverage'}
              </button>
            </form>
            
            {error && <div className="error-message">{error}</div>}
            
            {jobStatus && (
              <div className="status-message">
                <p>Status: <strong>{jobStatus.status}</strong></p>
                {jobStatus.status === 'pending' && <p>Processing your request...</p>}
                {jobStatus.status === 'completed' && jobStatus.result && (
                  <p>Coverage Radius: {jobStatus.result.coverage_radius_km?.toFixed(2)} km</p>
                )}
              </div>
            )}
          </div>
          
          <div className="scenarios-section">
            <h2>Saved Scenarios</h2>
            <div className="scenarios-list">
              {scenarios.map(scenario => (
                <div key={scenario.id} className="scenario-item">
                  <strong>{scenario.name}</strong>
                  <p>Lat: {scenario.latitude.toFixed(4)}, Lng: {scenario.longitude.toFixed(4)}</p>
                  <p>Freq: {scenario.frequency_mhz} MHz</p>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="map-container">
          <MapContainer
            center={position}
            zoom={10}
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            <LocationMarker position={position} setPosition={handleMapClick} />
            
            {coverageData.map((coverage, index) => (
              <Polygon
                key={coverage.id || index}
                positions={geoJsonToLeaflet(coverage.geojson)}
                color="blue"
                fillColor="blue"
                fillOpacity={0.2}
              >
                <Popup>
                  <div>
                    <strong>{coverage.scenario_name}</strong>
                    <p>Radius: {coverage.coverage_radius_km.toFixed(2)} km</p>
                  </div>
                </Popup>
              </Polygon>
            ))}
          </MapContainer>
        </div>
      </div>
    </div>
  );
}

export default App;

